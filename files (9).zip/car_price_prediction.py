"""
Car Price Prediction with Machine Learning
============================================
Full workflow: data loading -> cleaning -> feature engineering ->
model training (Linear Regression, Lasso, Random Forest) -> evaluation -> visualization

Dataset: car data.csv (Kaggle "Vehicle dataset" - 301 records)
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression, Lasso
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler

sns.set_style("whitegrid")
plt.rcParams["figure.dpi"] = 110

OUT = "/home/claude/car_data/outputs"
import os
os.makedirs(OUT, exist_ok=True)

# ---------------------------------------------------------------
# 1. LOAD DATA
# ---------------------------------------------------------------
df = pd.read_csv("car data.csv")
print("Shape:", df.shape)
print(df.head())
print(df.info())
print(df.isnull().sum())
print(df.describe(include="all"))

n_rows_raw, n_cols_raw = df.shape
n_duplicates = df.duplicated().sum()
n_missing = int(df.isnull().sum().sum())

# ---------------------------------------------------------------
# 2. DATA CLEANING
# ---------------------------------------------------------------
df = df.drop_duplicates()

# ---------------------------------------------------------------
# 3. FEATURE ENGINEERING
# ---------------------------------------------------------------
CURRENT_YEAR = 2020  # dataset was published ~2020 (Year column max is 2018)
df["Car_Age"] = CURRENT_YEAR - df["Year"]

# Brand extraction from Car_Name (first word) -> proxy for "brand goodwill"
df["Brand"] = df["Car_Name"].apply(lambda x: str(x).split(" ")[0].strip().lower())

# Mileage per year (usage intensity)
df["Kms_Per_Year"] = df["Driven_kms"] / df["Car_Age"].replace(0, 1)

df = df.drop(columns=["Car_Name", "Year"])

# NOTE on leakage avoidance:
# A "Brand_Goodwill" feature is computed below, but deliberately from Present_Price
# (the showroom/ex-showroom price), NOT from Selling_Price (the target). Using the
# target to build a feature would leak the answer into the model and inflate R^2
# artificially. Present_Price is a legitimate proxy for brand prestige/goodwill
# because premium brands command a higher showroom price independent of the resale
# value we are trying to predict. The brand-level average is also computed on the
# training split only (see step 6) and then mapped onto the test split, so no
# information from the test rows leaks into the training features either.

# ---------------------------------------------------------------
# 4. EXPLORATORY VISUALS
# ---------------------------------------------------------------
fig, axes = plt.subplots(1, 3, figsize=(15, 4))
sns.histplot(df["Selling_Price"], bins=25, kde=True, ax=axes[0], color="#4C72B0")
axes[0].set_title("Distribution of Selling Price (Lakhs)")
sns.scatterplot(data=df, x="Present_Price", y="Selling_Price", hue="Fuel_Type", ax=axes[1])
axes[1].set_title("Present Price vs Selling Price")
sns.scatterplot(data=df, x="Car_Age", y="Selling_Price", ax=axes[2], color="#DD8452")
axes[2].set_title("Car Age vs Selling Price")
plt.tight_layout()
plt.savefig(f"{OUT}/eda_overview.png")
plt.close()

corr_cols = ["Selling_Price", "Present_Price", "Driven_kms", "Owner", "Car_Age", "Kms_Per_Year"]
plt.figure(figsize=(7, 6))
sns.heatmap(df[corr_cols].corr(), annot=True, fmt=".2f", cmap="coolwarm", center=0)
plt.title("Feature Correlation Heatmap")
plt.tight_layout()
plt.savefig(f"{OUT}/correlation_heatmap.png")
plt.close()

# ---------------------------------------------------------------
# 5. ENCODING CATEGORICAL FEATURES
# ---------------------------------------------------------------
categorical_cols = ["Fuel_Type", "Selling_type", "Transmission"]
df_encoded = pd.get_dummies(df, columns=categorical_cols, drop_first=True)

X = df_encoded.drop(columns=["Selling_Price", "Brand"])
y = df_encoded["Selling_Price"]
brands = df_encoded["Brand"]

feature_names = list(X.columns) + ["Brand_Goodwill"]

# ---------------------------------------------------------------
# 6. TRAIN / TEST SPLIT (leakage-safe Brand_Goodwill) + SCALING
# ---------------------------------------------------------------
X_train, X_test, y_train, y_test, brand_train, brand_test = train_test_split(
    X, y, brands, test_size=0.2, random_state=42
)

# Brand_Goodwill = mean showroom (Present_Price) value per brand, LEARNED FROM
# THE TRAINING SPLIT ONLY, then applied to the test split. Unseen brands in the
# test set fall back to the training-set global mean present price.
train_present_price = X_train["Present_Price"]
goodwill_map = train_present_price.groupby(brand_train).mean()
global_goodwill = train_present_price.mean()

X_train = X_train.copy()
X_test = X_test.copy()
X_train["Brand_Goodwill"] = brand_train.map(goodwill_map).values
X_test["Brand_Goodwill"] = brand_test.map(goodwill_map).fillna(global_goodwill).values

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ---------------------------------------------------------------
# 7. MODEL TRAINING
# ---------------------------------------------------------------
models = {
    "Linear Regression": LinearRegression(),
    "Lasso Regression": Lasso(alpha=0.05, random_state=42),
    "Random Forest": RandomForestRegressor(n_estimators=300, max_depth=8, random_state=42),
}

results = []
predictions = {}
for name, model in models.items():
    if name == "Random Forest":
        model.fit(X_train, y_train)  # tree model - no scaling needed
        preds = model.predict(X_test)
        # 5-fold CV performed WITHIN the training split only, so Brand_Goodwill
        # (and any other split-derived feature) never sees held-out rows.
        cv = cross_val_score(model, X_train, y_train, cv=5, scoring="r2")
    else:
        model.fit(X_train_scaled, y_train)
        preds = model.predict(X_test_scaled)
        cv = cross_val_score(model, X_train_scaled, y_train, cv=5, scoring="r2")

    predictions[name] = preds
    mae = mean_absolute_error(y_test, preds)
    rmse = np.sqrt(mean_squared_error(y_test, preds))
    r2 = r2_score(y_test, preds)
    results.append({
        "Model": name, "MAE": round(mae, 3), "RMSE": round(rmse, 3),
        "R2_Score": round(r2, 4), "CV_R2_Mean": round(cv.mean(), 4), "CV_R2_Std": round(cv.std(), 4)
    })

results_df = pd.DataFrame(results).sort_values("R2_Score", ascending=False)
print("\n=== MODEL COMPARISON ===")
print(results_df.to_string(index=False))
results_df.to_csv(f"{OUT}/model_comparison.csv", index=False)

best_model_name = results_df.iloc[0]["Model"]
best_model = models[best_model_name]

# ---------------------------------------------------------------
# 8. FEATURE IMPORTANCE (Random Forest) & COEFFICIENTS (Linear)
# ---------------------------------------------------------------
rf_model = models["Random Forest"]
importances = pd.Series(rf_model.feature_importances_, index=feature_names).sort_values(ascending=False)

plt.figure(figsize=(8, 6))
sns.barplot(x=importances.values, y=importances.index, color="#55A868")
plt.title("Random Forest — Feature Importance")
plt.xlabel("Importance")
plt.tight_layout()
plt.savefig(f"{OUT}/feature_importance.png")
plt.close()

lr_model = models["Linear Regression"]
lr_coefs = pd.Series(lr_model.coef_, index=feature_names).sort_values(key=abs, ascending=False)

# ---------------------------------------------------------------
# 9. ACTUAL VS PREDICTED PLOTS
# ---------------------------------------------------------------
fig, axes = plt.subplots(1, 3, figsize=(16, 4.5))
for ax, (name, preds) in zip(axes, predictions.items()):
    ax.scatter(y_test, preds, alpha=0.6, color="#4C72B0", edgecolor="k", linewidth=0.3)
    lims = [min(y_test.min(), preds.min()), max(y_test.max(), preds.max())]
    ax.plot(lims, lims, "r--", linewidth=1.5)
    ax.set_xlabel("Actual Selling Price")
    ax.set_ylabel("Predicted Selling Price")
    r2 = r2_score(y_test, preds)
    ax.set_title(f"{name}\nR² = {r2:.3f}")
plt.tight_layout()
plt.savefig(f"{OUT}/actual_vs_predicted.png")
plt.close()

# Model comparison bar chart
plt.figure(figsize=(7, 4.5))
sns.barplot(data=results_df, x="Model", y="R2_Score", palette="viridis")
plt.title("Model Comparison — R² Score on Test Set")
plt.ylim(0, 1)
plt.tight_layout()
plt.savefig(f"{OUT}/model_r2_comparison.png")
plt.close()

# Residuals plot for the best model
best_preds = predictions[best_model_name]
residuals = y_test - best_preds
plt.figure(figsize=(7, 4.5))
sns.scatterplot(x=best_preds, y=residuals, color="#C44E52")
plt.axhline(0, color="black", linestyle="--")
plt.xlabel("Predicted Selling Price")
plt.ylabel("Residual (Actual - Predicted)")
plt.title(f"Residual Plot — {best_model_name}")
plt.tight_layout()
plt.savefig(f"{OUT}/residual_plot.png")
plt.close()

print("\nBest Model:", best_model_name)
print("\nData summary for report:")
print("raw_rows:", n_rows_raw, "raw_cols:", n_cols_raw, "duplicates_removed:", n_duplicates, "missing_values:", n_missing)
print("final_shape:", df_encoded.shape)
print("\nTop features (RF):\n", importances.head(8))
print("\nLinear coefs:\n", lr_coefs)

# Save cleaned data + summary stats for reporting
df.to_csv(f"{OUT}/cleaned_engineered_data.csv", index=False)
with open(f"{OUT}/summary.txt", "w") as f:
    f.write(f"raw_rows={n_rows_raw}\nraw_cols={n_cols_raw}\nduplicates_removed={n_duplicates}\nmissing_values={n_missing}\n")
    f.write(f"final_rows={df_encoded.shape[0]}\nfinal_cols={df_encoded.shape[1]}\n")
    f.write(f"best_model={best_model_name}\n")
    f.write(f"features={feature_names}\n")
    f.write("\nImportances:\n" + importances.to_string())
    f.write("\n\nLinear Coefs:\n" + lr_coefs.to_string())
    f.write("\n\nResults:\n" + results_df.to_string(index=False))
